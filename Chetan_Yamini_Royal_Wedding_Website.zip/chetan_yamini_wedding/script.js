const music = document.getElementById("weddingMusic");
const musicToggle = document.getElementById("musicToggle");

musicToggle.addEventListener("click", async () => {
  if (music.paused) {
    try {
      await music.play();
      musicToggle.textContent = "♫ शहनाई बंद करा";
      musicToggle.setAttribute("aria-pressed", "true");
    } catch (error) {
      alert("शहनाई सुरू करण्यासाठी प्रोजेक्ट फोल्डरमध्ये shehnai.mp3 ही ऑडिओ फाइल ठेवा.");
    }
  } else {
    music.pause();
    musicToggle.textContent = "♫ शहनाई सुरू करा";
    musicToggle.setAttribute("aria-pressed", "false");
  }
});

// Wedding date: 25 November 2026, 11:49 AM (India Standard Time)
const weddingDate = new Date("2026-11-25T11:49:00+05:30").getTime();
function updateCountdown() {
  const diff = weddingDate - Date.now();
  if (diff <= 0) {
    document.getElementById("countdown").innerHTML = "<p>शुभविवाह सोहळ्याचा मंगलमय दिवस उजाडला आहे! 💐</p>";
    return;
  }
  const values = {
    days: Math.floor(diff / 86400000),
    hours: Math.floor((diff % 86400000) / 3600000),
    minutes: Math.floor((diff % 3600000) / 60000),
    seconds: Math.floor((diff % 60000) / 1000)
  };
  Object.entries(values).forEach(([id, value]) => {
    document.getElementById(id).textContent = String(value).padStart(2, "0");
  });
}
updateCountdown();
setInterval(updateCountdown, 1000);

// Light falling-flower effect
const petalLayer = document.querySelector(".petal-layer");
function createPetal() {
  const petal = document.createElement("span");
  petal.className = "petal";
  petal.textContent = Math.random() > .5 ? "✿" : "❀";
  petal.style.left = Math.random() * 100 + "vw";
  petal.style.fontSize = (12 + Math.random() * 13) + "px";
  const duration = 7 + Math.random() * 7;
  petal.style.animationDuration = duration + "s";
  petalLayer.appendChild(petal);
  setTimeout(() => petal.remove(), duration * 1000);
}
setInterval(createPetal, 850);
