CHETAN & YAMINI - ROYAL TRADITIONAL WEDDING INVITATION

FILES
- index.html : invitation page
- style.css  : design, responsive layout and animations
- script.js  : countdown, falling petals and music button

HOW TO PREVIEW
1. Extract the ZIP file.
2. Keep all files in the same folder.
3. Open index.html in Chrome.

SHEHNAI MUSIC
Add an audio file named exactly "shehnai.mp3" in this same folder.
Use music that you have permission to use. Then tap "शहनाई सुरू करा".

PUBLISH ONLINE WITH VERCEL
1. Go to https://vercel.com and sign in.
2. Create a new project and import this folder/repository, or deploy it using Vercel CLI.
3. The site is static; no build command is required.
4. After deployment, share the generated URL on WhatsApp.

EDITING
Change names, family details, date, time and venue in index.html.
Change the wedding date in script.js if the date/time changes.
Google Fonts need an internet connection; fallback fonts will be used offline.
